
var contactForm = document.getElementById('contactForm');
contactForm.addEventListener('submit', function(event) {
    event.preventDefault(); 
    modal.style.display = 'block'; 
});

var modal = document.getElementById('myModal');


var closeBtn = document.getElementById('closeBtn');


closeBtn.addEventListener('click', function() {
    modal.style.display = 'none'; 
});


window.addEventListener('click', function(event) {
    if (event.target == modal) {
        modal.style.display = 'none'; 
    }
});
